import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Program from './components/Program';
import Service from './components/Service';
import About from './components/About';
import Community from './components/Community';
import Classes from './components/Classes';
import Trainers from './components/Trainers';
import Pricing from './components/Pricing';
import Blog from './components/Blog';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ThemeSwitcher from './components/ThemeSwitcher';
import ProgressTracker from './features/progress/ProgressTracker';
import SocialFeatures from './features/social/SocialFeatures';
import WorkoutManager from './features/workout/WorkoutManager';
import NutritionManager from './features/nutrition/NutritionManager';
import PersonalizationManager from './features/personalization/PersonalizationManager';
import AnalyticsManager from './features/analytics/AnalyticsManager';
import NotificationManager from './features/notifications/NotificationManager';
import SettingsManager from './features/settings/SettingsManager';
import AchievementManager from './features/achievements/AchievementManager';
import ChallengeManager from './features/challenges/ChallengeManager';
import GoalManager from './features/goals/GoalManager';
import './App.css';

function App() {
  // Initialize managers
  const [progressTracker] = useState(new ProgressTracker());
  const [socialFeatures] = useState(new SocialFeatures());
  const [workoutManager] = useState(new WorkoutManager());
  const [nutritionManager] = useState(new NutritionManager());
  const [personalizationManager] = useState(new PersonalizationManager());
  const [analyticsManager] = useState(new AnalyticsManager());
  const [notificationManager] = useState(new NotificationManager());
  const [settingsManager] = useState(new SettingsManager());
  const [achievementManager] = useState(new AchievementManager());
  const [challengeManager] = useState(new ChallengeManager());
  const [goalManager] = useState(new GoalManager());

  // App state
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Initialize app
  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      setLoading(true);
      // Load user settings
      settingsManager.loadSettings();
      
      // Initialize user preferences
      const preferences = settingsManager.getPreferences();
      personalizationManager.updateUserPreferences(preferences);

      // Set up notification subscriptions
      setupNotifications();

      // Load user data
      await loadUserData();

      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const setupNotifications = () => {
    // Subscribe to various notifications
    notificationManager.subscribe(handleNotification);
    
    // Set up achievement notifications
    achievementManager.notifyAchievementUnlocked = (achievement) => {
      notificationManager.createNotification(
        'achievement',
        'Achievement Unlocked!',
        `Congratulations! You've unlocked the ${achievement.name} achievement!`
      );
    };

    // Set up goal notifications
    goalManager.notifyGoalCompleted = (goal) => {
      notificationManager.createNotification(
        'goal',
        'Goal Completed!',
        `Congratulations! You've completed your ${goal.name} goal!`
      );
    };

    // Set up challenge notifications
    challengeManager.notifyChallengeStarted = (challenge) => {
      notificationManager.createNotification(
        'challenge',
        'Challenge Started',
        `The ${challenge.name} challenge has begun!`
      );
    };
  };

  const loadUserData = async () => {
    // Load user profile
    const profile = settingsManager.getProfile();
    setUser(profile);

    // Load achievements
    achievementManager.createWorkoutAchievements();
    achievementManager.createNutritionAchievements();
    achievementManager.createProgressAchievements();
    achievementManager.createSocialAchievements();
    achievementManager.createStreakAchievements();

    // Load active goals
    const activeGoals = goalManager.getActiveGoals();
    if (activeGoals.length === 0) {
      createDefaultGoals();
    }

    // Load active challenges
    const activeChallenges = challengeManager.getChallenges({ status: 'active' });
    if (activeChallenges.length === 0) {
      createDefaultChallenges();
    }
  };

  const createDefaultGoals = () => {
    // Create default weight goal
    goalManager.createWeightGoal(
      'Initial Weight Goal',
      75,
      new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      [
        { id: 1, target: 80, description: 'First milestone' },
        { id: 2, target: 77, description: 'Second milestone' }
      ]
    );

    // Create default workout goal
    goalManager.createWorkoutGoal(
      'Weekly Workouts',
      3,
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    );
  };

  const createDefaultChallenges = () => {
    // Create default workout challenge
    challengeManager.createWorkoutChallenge(
      '30-Day Workout Challenge',
      'Complete daily workouts for 30 days',
      { workouts: 30 },
      30,
      {
        first: { points: 1000, badge: 'gold' },
        second: { points: 500, badge: 'silver' },
        third: { points: 250, badge: 'bronze' },
        participation: { points: 100 }
      }
    );
  };

  const handleNotification = (notification) => {
    // Handle incoming notifications
    console.log('New notification:', notification);
  };

  // Render loading state
  if (loading) {
    return <div>Loading...</div>;
  }

  // Render error state
  if (error) {
    return <div>Error: {error}</div>;
  }

  // Render main app
  return (
    <Router>
      <div className="app">
        <ThemeSwitcher />
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/program" element={<Program />} />
          <Route path="/service" element={<Service />} />
          <Route path="/about" element={<About />} />
          <Route path="/community" element={<Community />} />
          <Route path="/classes" element={<Classes />} />
          <Route path="/trainers" element={<Trainers />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/testimonials" element={<Testimonials />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App; 