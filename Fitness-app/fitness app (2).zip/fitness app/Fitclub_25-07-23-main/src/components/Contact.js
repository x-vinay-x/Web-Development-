import React, { useState } from 'react';
import './Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ type: 'loading', message: 'Sending message...' });

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error('Failed to send message');

      setStatus({
        type: 'success',
        message: 'Message sent successfully! We will get back to you soon.'
      });
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (error) {
      setStatus({
        type: 'error',
        message: 'Failed to send message. Please try again later.'
      });
    }
  };

  return (
    <div className="contact-container">
      <h2>Get in Touch</h2>
      <div className="contact-content">
        <div className="contact-info">
          <div className="info-card">
            <i className="ri-map-pin-line"></i>
            <h3>Location</h3>
            <p>123 Fitness Street</p>
            <p>New York, NY 10001</p>
          </div>
          <div className="info-card">
            <i className="ri-mail-line"></i>
            <h3>Email</h3>
            <p>info@fitclub.com</p>
            <p>support@fitclub.com</p>
          </div>
          <div className="info-card">
            <i className="ri-phone-line"></i>
            <h3>Phone</h3>
            <p>+1 (555) 123-4567</p>
            <p>+1 (555) 987-6543</p>
          </div>
          <div className="info-card">
            <i className="ri-time-line"></i>
            <h3>Working Hours</h3>
            <p>Mon - Fri: 6:00 AM - 10:00 PM</p>
            <p>Sat - Sun: 7:00 AM - 8:00 PM</p>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="Your name"
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Your email"
            />
          </div>
          <div className="form-group">
            <label htmlFor="subject">Subject</label>
            <input
              type="text"
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              placeholder="Subject"
            />
          </div>
          <div className="form-group">
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              placeholder="Your message"
              rows="5"
            ></textarea>
          </div>
          <button type="submit" className="submit-btn">
            Send Message
          </button>
          {status.message && (
            <div className={`status-message ${status.type}`}>
              {status.message}
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default Contact; 