import React, { useEffect } from 'react';
import './Community.css';

const Community = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.community-section').forEach((section) => {
      observer.observe(section);
    });
  }, []);

  return (
    <div className="community">
      <section className="community-hero community-section">
        <div className="community-hero-content">
          <h1>Our Community</h1>
          <p>Join our vibrant fitness community and achieve your goals together</p>
        </div>
      </section>

      <section className="community-events community-section">
        <h2>Upcoming Events</h2>
        <div className="events-grid">
          <div className="event-card">
            <div className="event-date">
              <span className="day">15</span>
              <span className="month">JUN</span>
            </div>
            <div className="event-details">
              <h3>Summer Fitness Challenge</h3>
              <p>Join our 30-day summer fitness challenge</p>
              <span className="event-time"><i className="ri-time-fill"></i> 9:00 AM</span>
            </div>
          </div>
          <div className="event-card">
            <div className="event-date">
              <span className="day">22</span>
              <span className="month">JUN</span>
            </div>
            <div className="event-details">
              <h3>Nutrition Workshop</h3>
              <p>Learn about healthy eating habits</p>
              <span className="event-time"><i className="ri-time-fill"></i> 2:00 PM</span>
            </div>
          </div>
          <div className="event-card">
            <div className="event-date">
              <span className="day">29</span>
              <span className="month">JUN</span>
            </div>
            <div className="event-details">
              <h3>Yoga Retreat</h3>
              <p>Weekend yoga retreat for all levels</p>
              <span className="event-time"><i className="ri-time-fill"></i> 10:00 AM</span>
            </div>
          </div>
        </div>
      </section>

      <section className="community-gallery community-section">
        <h2>Community Gallery</h2>
        <div className="gallery-grid">
          <div className="gallery-item">
            <img src="/assets/gallery1.jpg" alt="Community Event 1" />
          </div>
          <div className="gallery-item">
            <img src="/assets/gallery2.jpg" alt="Community Event 2" />
          </div>
          <div className="gallery-item">
            <img src="/assets/gallery3.jpg" alt="Community Event 3" />
          </div>
          <div className="gallery-item">
            <img src="/assets/gallery4.jpg" alt="Community Event 4" />
          </div>
          <div className="gallery-item">
            <img src="/assets/gallery5.jpg" alt="Community Event 5" />
          </div>
          <div className="gallery-item">
            <img src="/assets/gallery6.jpg" alt="Community Event 6" />
          </div>
        </div>
      </section>

      <section className="community-join community-section">
        <div className="join-content">
          <h2>Join Our Community</h2>
          <p>Be part of our growing fitness family and share your journey with like-minded individuals</p>
          <button className="btn">Join Now</button>
        </div>
      </section>
    </div>
  );
};

export default Community; 