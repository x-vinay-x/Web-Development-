import React from 'react';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>FitClub</h3>
          <p>
            Transform your body and mind with our state-of-the-art fitness facilities
            and expert trainers. Join us on your journey to a healthier lifestyle.
          </p>
          <div className="social-links">
            <a href="#" className="social-link">
              <i className="ri-facebook-fill"></i>
            </a>
            <a href="#" className="social-link">
              <i className="ri-instagram-line"></i>
            </a>
            <a href="#" className="social-link">
              <i className="ri-twitter-fill"></i>
            </a>
            <a href="#" className="social-link">
              <i className="ri-youtube-fill"></i>
            </a>
          </div>
        </div>

        <div className="footer-section">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#classes">Classes</a></li>
            <li><a href="#trainers">Trainers</a></li>
            <li><a href="#pricing">Pricing</a></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Programs</h4>
          <ul>
            <li><a href="#strength">Strength Training</a></li>
            <li><a href="#cardio">Cardio</a></li>
            <li><a href="#yoga">Yoga</a></li>
            <li><a href="#crossfit">CrossFit</a></li>
            <li><a href="#nutrition">Nutrition</a></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Contact Info</h4>
          <ul className="contact-info">
            <li>
              <i className="ri-map-pin-line"></i>
              <span>123 Fitness Street, New York, NY 10001</span>
            </li>
            <li>
              <i className="ri-phone-line"></i>
              <span>+1 (555) 123-4567</span>
            </li>
            <li>
              <i className="ri-mail-line"></i>
              <span>info@fitclub.com</span>
            </li>
            <li>
              <i className="ri-time-line"></i>
              <span>Mon - Fri: 6:00 AM - 10:00 PM</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {currentYear} FitClub. All rights reserved.</p>
        <div className="footer-bottom-links">
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
          <a href="#cookies">Cookie Policy</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 