import React, { useState } from 'react';
import './BMICalculator.css';

const BMICalculator = () => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [category, setCategory] = useState('');

  const calculateBMI = (e) => {
    e.preventDefault();
    
    if (!height || !weight) {
      alert('Please enter both height and weight');
      return;
    }

    const heightInMeters = height / 100;
    const bmiValue = (weight / (heightInMeters * heightInMeters)).toFixed(1);
    setBmi(bmiValue);

    // Determine BMI category
    if (bmiValue < 18.5) {
      setCategory('Underweight');
    } else if (bmiValue >= 18.5 && bmiValue < 25) {
      setCategory('Normal weight');
    } else if (bmiValue >= 25 && bmiValue < 30) {
      setCategory('Overweight');
    } else {
      setCategory('Obese');
    }
  };

  return (
    <div className="bmi-calculator">
      <h2>BMI Calculator</h2>
      <form onSubmit={calculateBMI}>
        <div className="form-group">
          <label htmlFor="height">Height (cm)</label>
          <input
            type="number"
            id="height"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder="Enter your height"
            min="50"
            max="250"
          />
        </div>
        <div className="form-group">
          <label htmlFor="weight">Weight (kg)</label>
          <input
            type="number"
            id="weight"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder="Enter your weight"
            min="20"
            max="300"
          />
        </div>
        <button type="submit" className="calculate-btn">
          Calculate BMI
        </button>
      </form>

      {bmi && (
        <div className="bmi-result">
          <h3>Your BMI Results</h3>
          <p className="bmi-value">BMI: {bmi}</p>
          <p className="bmi-category">Category: {category}</p>
          <div className="bmi-info">
            <h4>BMI Categories:</h4>
            <ul>
              <li>Underweight: BMI less than 18.5</li>
              <li>Normal weight: BMI 18.5-24.9</li>
              <li>Overweight: BMI 25-29.9</li>
              <li>Obese: BMI 30 or higher</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default BMICalculator; 