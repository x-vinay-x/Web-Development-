import React, { useState, useEffect } from 'react';
import './Blog.css';

const Blog = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    'all',
    'fitness-tips',
    'success-stories',
    'nutrition',
    'workout-plans'
  ];

  useEffect(() => {
    fetchPosts();
  }, [selectedCategory]);

  const fetchPosts = async () => {
    try {
      const response = await fetch(`/api/blog?category=${selectedCategory}`);
      if (!response.ok) throw new Error('Failed to fetch posts');
      const data = await response.json();
      setPosts(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching posts:', error);
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading posts...</div>;

  return (
    <div className="blog-container">
      <h2>Fitness Blog</h2>
      
      <div className="category-filter">
        {categories.map(category => (
          <button
            key={category}
            className={`category-btn ${selectedCategory === category ? 'active' : ''}`}
            onClick={() => setSelectedCategory(category)}
          >
            {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </button>
        ))}
      </div>

      <div className="blog-grid">
        {posts.map(post => (
          <article key={post._id} className="blog-card fade-in">
            <div className="blog-image">
              <img src={post.image} alt={post.title} />
              <span className="category-tag">{post.category}</span>
            </div>
            <div className="blog-content">
              <h3>{post.title}</h3>
              <p className="blog-excerpt">{post.excerpt}</p>
              <div className="blog-meta">
                <span className="author">
                  <i className="ri-user-line"></i> {post.author}
                </span>
                <span className="date">
                  <i className="ri-calendar-line"></i> {new Date(post.date).toLocaleDateString()}
                </span>
              </div>
              <button className="read-more-btn">Read More</button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Blog; 