import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Program.css';

const Program = () => {
  useEffect(() => {
    // Add fade-in animation to elements as they come into view
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.program-section').forEach((section) => {
      observer.observe(section);
    });
  }, []);

  return (
    <div className="program">
      <section className="program-hero program-section">
        <div className="program-hero-content">
          <h1>Our Programs</h1>
          <p>Discover our comprehensive fitness programs designed to help you achieve your goals</p>
        </div>
      </section>

      <section className="program-categories program-section">
        <h2>Program Categories</h2>
        <div className="program-grid">
          <div className="program-card">
            <i className="ri-boxing-fill"></i>
            <h3>Strength Training</h3>
            <p>Build muscle and increase your overall strength with our expert-led programs</p>
            <Link to="/program/strength" className="btn">Learn More</Link>
          </div>
          <div className="program-card">
            <i className="ri-heart-pulse-fill"></i>
            <h3>Cardio Fitness</h3>
            <p>Improve your endurance and cardiovascular health with our dynamic workouts</p>
            <Link to="/program/cardio" className="btn">Learn More</Link>
          </div>
          <div className="program-card">
            <i className="ri-run-line"></i>
            <h3>Weight Loss</h3>
            <p>Effective programs designed to help you achieve your weight loss goals</p>
            <Link to="/program/weight-loss" className="btn">Learn More</Link>
          </div>
          <div className="program-card">
            <i className="ri-shopping-basket-fill"></i>
            <h3>Weight Gain</h3>
            <p>Structured programs to help you gain healthy weight and build muscle</p>
            <Link to="/program/weight-gain" className="btn">Learn More</Link>
          </div>
        </div>
      </section>

      <section className="program-features program-section">
        <h2>Why Choose Our Programs?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <i className="ri-user-star-fill"></i>
            <h3>Expert Trainers</h3>
            <p>Learn from certified professionals with years of experience</p>
          </div>
          <div className="feature-card">
            <i className="ri-calendar-check-fill"></i>
            <h3>Flexible Schedule</h3>
            <p>Choose from multiple time slots that fit your routine</p>
          </div>
          <div className="feature-card">
            <i className="ri-group-fill"></i>
            <h3>Group Sessions</h3>
            <p>Train with like-minded individuals in a motivating environment</p>
          </div>
          <div className="feature-card">
            <i className="ri-line-chart-fill"></i>
            <h3>Progress Tracking</h3>
            <p>Monitor your improvements with our advanced tracking system</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Program; 