import React, { useState, useEffect } from 'react';
import './ClassBooking.css';

const ClassBooking = () => {
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const response = await fetch('/api/classes');
      if (!response.ok) {
        throw new Error('Failed to fetch classes');
      }
      const data = await response.json();
      setClasses(data);
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleBooking = async (classId) => {
    try {
      const response = await fetch(`/api/classes/${classId}/enroll`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to book class');
      }

      // Update the class list after successful booking
      fetchClasses();
      alert('Class booked successfully!');
    } catch (err) {
      alert(err.message);
    }
  };

  if (loading) return <div className="loading">Loading classes...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="class-booking">
      <h2>Book a Class</h2>
      <div className="class-grid">
        {classes.map((classItem) => (
          <div key={classItem._id} className="class-card">
            <div className="class-header">
              <h3>{classItem.name}</h3>
              <span className={`class-type ${classItem.type}`}>
                {classItem.type}
              </span>
            </div>
            <div className="class-details">
              <p><strong>Trainer:</strong> {classItem.trainer.name}</p>
              <p><strong>Schedule:</strong> {classItem.schedule.day} at {classItem.schedule.startTime}</p>
              <p><strong>Duration:</strong> {classItem.schedule.duration} minutes</p>
              <p><strong>Level:</strong> {classItem.level}</p>
              <p><strong>Available Spots:</strong> {classItem.capacity - classItem.enrolledMembers.length}</p>
            </div>
            <div className="class-actions">
              <button
                className={`book-btn ${classItem.enrolledMembers.length >= classItem.capacity ? 'disabled' : ''}`}
                onClick={() => handleBooking(classItem._id)}
                disabled={classItem.enrolledMembers.length >= classItem.capacity}
              >
                {classItem.enrolledMembers.length >= classItem.capacity ? 'Class Full' : 'Book Now'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ClassBooking; 