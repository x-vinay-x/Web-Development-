import React, { useState, useEffect } from 'react';
import './ProgressTracker.css';

const ProgressTracker = () => {
  const [progress, setProgress] = useState({
    workoutsCompleted: 0,
    totalPoints: 0,
    achievements: []
  });
  const [newWorkout, setNewWorkout] = useState({
    type: '',
    duration: '',
    intensity: 'medium',
    notes: ''
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProgress();
  }, []);

  const fetchProgress = async () => {
    try {
      const response = await fetch('/api/users/progress', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch progress');
      const data = await response.json();
      setProgress(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching progress:', error);
      setLoading(false);
    }
  };

  const handleWorkoutSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/users/workout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newWorkout)
      });

      if (!response.ok) throw new Error('Failed to log workout');
      
      // Reset form and fetch updated progress
      setNewWorkout({
        type: '',
        duration: '',
        intensity: 'medium',
        notes: ''
      });
      fetchProgress();
    } catch (error) {
      console.error('Error logging workout:', error);
    }
  };

  if (loading) return <div className="loading">Loading progress...</div>;

  return (
    <div className="progress-tracker">
      <div className="progress-summary">
        <h2>Your Progress</h2>
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Workouts Completed</h3>
            <p className="stat-value">{progress.workoutsCompleted}</p>
          </div>
          <div className="stat-card">
            <h3>Total Points</h3>
            <p className="stat-value">{progress.totalPoints}</p>
          </div>
        </div>
      </div>

      <div className="achievements-section">
        <h3>Achievements</h3>
        <div className="achievements-grid">
          {progress.achievements.map((achievement, index) => (
            <div key={index} className="achievement-card">
              <span className="achievement-icon">🏆</span>
              <p>{achievement}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="workout-log">
        <h3>Log New Workout</h3>
        <form onSubmit={handleWorkoutSubmit}>
          <div className="form-group">
            <label htmlFor="workout-type">Workout Type</label>
            <select
              id="workout-type"
              value={newWorkout.type}
              onChange={(e) => setNewWorkout({...newWorkout, type: e.target.value})}
              required
            >
              <option value="">Select type</option>
              <option value="strength">Strength Training</option>
              <option value="cardio">Cardio</option>
              <option value="yoga">Yoga</option>
              <option value="hiit">HIIT</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="duration">Duration (minutes)</label>
            <input
              type="number"
              id="duration"
              value={newWorkout.duration}
              onChange={(e) => setNewWorkout({...newWorkout, duration: e.target.value})}
              min="1"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="intensity">Intensity</label>
            <select
              id="intensity"
              value={newWorkout.intensity}
              onChange={(e) => setNewWorkout({...newWorkout, intensity: e.target.value})}
              required
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="notes">Notes</label>
            <textarea
              id="notes"
              value={newWorkout.notes}
              onChange={(e) => setNewWorkout({...newWorkout, notes: e.target.value})}
              placeholder="How was your workout?"
            />
          </div>

          <button type="submit" className="submit-btn">Log Workout</button>
        </form>
      </div>
    </div>
  );
};

export default ProgressTracker; 