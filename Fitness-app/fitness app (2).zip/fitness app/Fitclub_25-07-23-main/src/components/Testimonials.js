import React, { useState, useEffect } from 'react';
import './Testimonials.css';

const Testimonials = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      const response = await fetch('/api/testimonials');
      if (!response.ok) throw new Error('Failed to fetch testimonials');
      const data = await response.json();
      setTestimonials(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching testimonials:', error);
      setLoading(false);
    }
  };

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  if (loading) return <div className="loading">Loading testimonials...</div>;

  return (
    <div className="testimonials-container">
      <h2>Success Stories</h2>
      <div className="testimonials-slider">
        <button className="nav-btn prev" onClick={prevTestimonial}>
          <i className="ri-arrow-left-line"></i>
        </button>
        
        <div className="testimonial-card fade-in">
          <div className="testimonial-image">
            <img 
              src={testimonials[currentIndex]?.image} 
              alt={testimonials[currentIndex]?.name} 
            />
          </div>
          <div className="testimonial-content">
            <div className="quote-icon">
              <i className="ri-double-quotes-r"></i>
            </div>
            <p className="testimonial-text">
              {testimonials[currentIndex]?.text}
            </p>
            <div className="testimonial-author">
              <h4>{testimonials[currentIndex]?.name}</h4>
              <p>{testimonials[currentIndex]?.role}</p>
            </div>
            <div className="testimonial-stats">
              <div className="stat">
                <span className="stat-value">{testimonials[currentIndex]?.weightLoss}</span>
                <span className="stat-label">Weight Loss</span>
              </div>
              <div className="stat">
                <span className="stat-value">{testimonials[currentIndex]?.duration}</span>
                <span className="stat-label">Duration</span>
              </div>
            </div>
          </div>
        </div>

        <button className="nav-btn next" onClick={nextTestimonial}>
          <i className="ri-arrow-right-line"></i>
        </button>
      </div>

      <div className="testimonial-dots">
        {testimonials.map((_, index) => (
          <span
            key={index}
            className={`dot ${index === currentIndex ? 'active' : ''}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default Testimonials; 