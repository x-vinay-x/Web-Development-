import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const sections = document.querySelectorAll('.home-section');
    sections.forEach((section) => observer.observe(section));

    return () => {
      sections.forEach((section) => observer.unobserve(section));
    };
  }, []);

  return (
    <div className="home">
      <section id="home" className="home-section hero">
        <div className="hero-content">
          <h1>Transform Your Body, Transform Your Life</h1>
          <p>Join FitClub today and start your journey to a healthier, stronger you.</p>
          <div className="hero-buttons">
            <Link to="/program" className="btn primary">Get Started</Link>
            <Link to="/pricing" className="btn secondary">View Plans</Link>
          </div>
        </div>
      </section>

      <section id="features" className="home-section features">
        <h2>Why Choose FitClub?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <i className="ri-user-star-line"></i>
            <h3>Expert Trainers</h3>
            <p>Our certified trainers are here to guide you every step of the way.</p>
          </div>
          <div className="feature-card">
            <i className="ri-dumbbell-line"></i>
            <h3>Modern Equipment</h3>
            <p>State-of-the-art facilities and equipment for the best workout experience.</p>
          </div>
          <div className="feature-card">
            <i className="ri-group-line"></i>
            <h3>Community Support</h3>
            <p>Join a supportive community of like-minded fitness enthusiasts.</p>
          </div>
          <div className="feature-card">
            <i className="ri-calendar-line"></i>
            <h3>Flexible Schedule</h3>
            <p>Work out on your own time with our 24/7 access.</p>
          </div>
        </div>
      </section>

      <section id="cta" className="home-section cta">
        <div className="cta-content">
          <h2>Start Your Fitness Journey Today</h2>
          <p>Get 50% off your first month when you join now!</p>
          <Link to="/pricing" className="btn primary">Join Now</Link>
        </div>
      </section>
    </div>
  );
};

export default Home; 