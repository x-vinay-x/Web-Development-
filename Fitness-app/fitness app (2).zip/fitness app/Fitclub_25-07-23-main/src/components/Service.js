import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Service.css';

const Service = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.service-section').forEach((section) => {
      observer.observe(section);
    });
  }, []);

  return (
    <div className="service">
      <section className="service-hero service-section">
        <div className="service-hero-content">
          <h1>Our Services</h1>
          <p>Discover our comprehensive range of fitness services designed to help you achieve your goals</p>
        </div>
      </section>

      <section className="service-categories service-section">
        <h2>Our Services</h2>
        <div className="service-grid">
          <div className="service-card">
            <i className="ri-user-star-fill"></i>
            <h3>Personal Training</h3>
            <p>One-on-one training sessions with expert trainers</p>
            <Link to="/service/personal-training" className="btn">Learn More</Link>
          </div>
          <div className="service-card">
            <i className="ri-group-fill"></i>
            <h3>Group Classes</h3>
            <p>High-energy group workouts for all fitness levels</p>
            <Link to="/service/group-classes" className="btn">Learn More</Link>
          </div>
          <div className="service-card">
            <i className="ri-heart-pulse-fill"></i>
            <h3>Nutrition Planning</h3>
            <p>Personalized nutrition plans to support your fitness goals</p>
            <Link to="/service/nutrition" className="btn">Learn More</Link>
          </div>
          <div className="service-card">
            <i className="ri-line-chart-fill"></i>
            <h3>Progress Tracking</h3>
            <p>Advanced tracking systems to monitor your progress</p>
            <Link to="/service/progress-tracking" className="btn">Learn More</Link>
          </div>
        </div>
      </section>

      <section className="service-features service-section">
        <h2>Why Choose Our Services?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <i className="ri-medal-fill"></i>
            <h3>Expert Guidance</h3>
            <p>Learn from certified professionals with years of experience</p>
          </div>
          <div className="feature-card">
            <i className="ri-tools-fill"></i>
            <h3>Modern Equipment</h3>
            <p>Access to state-of-the-art fitness equipment and facilities</p>
          </div>
          <div className="feature-card">
            <i className="ri-customer-service-2-fill"></i>
            <h3>24/7 Support</h3>
            <p>Round-the-clock support for all your fitness needs</p>
          </div>
          <div className="feature-card">
            <i className="ri-shield-check-fill"></i>
            <h3>Safe Environment</h3>
            <p>Clean and safe facilities with proper safety protocols</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Service; 