const express = require('express');
const router = express.Router();
const Class = require('../models/Class');
const { auth, checkRole } = require('../middleware/auth');

// Get all classes
router.get('/', async (req, res) => {
  try {
    const classes = await Class.find()
      .populate('trainer', 'name email')
      .populate('enrolledMembers', 'name email');
    res.json(classes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get class by ID
router.get('/:id', async (req, res) => {
  try {
    const classData = await Class.findById(req.params.id)
      .populate('trainer', 'name email')
      .populate('enrolledMembers', 'name email');
    
    if (!classData) {
      return res.status(404).json({ error: 'Class not found' });
    }
    
    res.json(classData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new class (admin/trainer only)
router.post('/', auth, checkRole(['admin', 'trainer']), async (req, res) => {
  try {
    const classData = new Class({
      ...req.body,
      trainer: req.user._id
    });
    
    await classData.save();
    res.status(201).json(classData);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update class (admin/trainer only)
router.patch('/:id', auth, checkRole(['admin', 'trainer']), async (req, res) => {
  try {
    const classData = await Class.findById(req.params.id);
    
    if (!classData) {
      return res.status(404).json({ error: 'Class not found' });
    }
    
    // Check if user is the trainer or admin
    if (classData.trainer.toString() !== req.user._id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized to update this class' });
    }
    
    Object.assign(classData, req.body);
    await classData.save();
    
    res.json(classData);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Enroll in class
router.post('/:id/enroll', auth, async (req, res) => {
  try {
    const classData = await Class.findById(req.params.id);
    
    if (!classData) {
      return res.status(404).json({ error: 'Class not found' });
    }
    
    if (!classData.canEnroll(req.user._id)) {
      return res.status(400).json({ error: 'Cannot enroll in this class' });
    }
    
    classData.enrolledMembers.push(req.user._id);
    await classData.save();
    
    res.json(classData);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Cancel enrollment
router.post('/:id/cancel', auth, async (req, res) => {
  try {
    const classData = await Class.findById(req.params.id);
    
    if (!classData) {
      return res.status(404).json({ error: 'Class not found' });
    }
    
    const memberIndex = classData.enrolledMembers.indexOf(req.user._id);
    if (memberIndex === -1) {
      return res.status(400).json({ error: 'Not enrolled in this class' });
    }
    
    classData.enrolledMembers.splice(memberIndex, 1);
    await classData.save();
    
    res.json(classData);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router; 