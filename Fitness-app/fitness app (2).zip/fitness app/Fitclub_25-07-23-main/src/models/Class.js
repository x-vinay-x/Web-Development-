const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['strength', 'cardio', 'yoga', 'pilates', 'hiit', 'crossfit'],
    required: true
  },
  trainer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  schedule: {
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      required: true
    },
    startTime: {
      type: String,
      required: true
    },
    duration: {
      type: Number, // in minutes
      required: true
    }
  },
  capacity: {
    type: Number,
    required: true
  },
  enrolledMembers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  level: {
    type: String,
    enum: ['beginner', 'intermediate', 'advanced'],
    required: true
  },
  equipment: [String],
  location: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['scheduled', 'in-progress', 'completed', 'cancelled'],
    default: 'scheduled'
  }
}, {
  timestamps: true
});

// Virtual for checking if class is full
classSchema.virtual('isFull').get(function() {
  return this.enrolledMembers.length >= this.capacity;
});

// Method to check if a user can enroll
classSchema.methods.canEnroll = function(userId) {
  return !this.isFull && !this.enrolledMembers.includes(userId);
};

module.exports = mongoose.model('Class', classSchema); 