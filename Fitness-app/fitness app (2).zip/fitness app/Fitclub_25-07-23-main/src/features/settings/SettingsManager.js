class SettingsManager {
    constructor() {
        this.settings = {
            profile: {
                name: '',
                email: '',
                age: null,
                gender: '',
                height: null,
                weight: null,
                fitnessLevel: 'beginner',
                goals: []
            },
            preferences: {
                theme: 'light',
                language: 'en',
                units: 'metric',
                notifications: {
                    workout: true,
                    nutrition: true,
                    progress: true,
                    social: true,
                    system: true
                },
                privacy: {
                    profileVisibility: 'public',
                    showProgress: true,
                    showWorkouts: true,
                    showNutrition: true
                }
            },
            workout: {
                defaultDuration: 45,
                restBetweenSets: 60,
                warmupDuration: 10,
                cooldownDuration: 5,
                preferredExercises: [],
                excludedExercises: []
            },
            nutrition: {
                dietaryRestrictions: [],
                mealPreferences: [],
                waterGoal: 2000,
                calorieGoal: 2000,
                macroGoals: {
                    protein: 30,
                    carbs: 40,
                    fats: 30
                }
            },
            social: {
                autoShare: false,
                shareWorkouts: false,
                shareProgress: false,
                shareNutrition: false,
                allowChallenges: true,
                allowMessages: true
            }
        };
    }

    // Profile settings
    updateProfile(profileData) {
        this.settings.profile = {
            ...this.settings.profile,
            ...profileData
        };
        this.saveSettings();
    }

    // User preferences
    updatePreferences(preferences) {
        this.settings.preferences = {
            ...this.settings.preferences,
            ...preferences
        };
        this.saveSettings();
    }

    updateNotificationSettings(notificationSettings) {
        this.settings.preferences.notifications = {
            ...this.settings.preferences.notifications,
            ...notificationSettings
        };
        this.saveSettings();
    }

    updatePrivacySettings(privacySettings) {
        this.settings.preferences.privacy = {
            ...this.settings.preferences.privacy,
            ...privacySettings
        };
        this.saveSettings();
    }

    // Workout settings
    updateWorkoutSettings(workoutSettings) {
        this.settings.workout = {
            ...this.settings.workout,
            ...workoutSettings
        };
        this.saveSettings();
    }

    addPreferredExercise(exercise) {
        if (!this.settings.workout.preferredExercises.includes(exercise)) {
            this.settings.workout.preferredExercises.push(exercise);
            this.saveSettings();
        }
    }

    removePreferredExercise(exercise) {
        this.settings.workout.preferredExercises = 
            this.settings.workout.preferredExercises.filter(e => e !== exercise);
        this.saveSettings();
    }

    addExcludedExercise(exercise) {
        if (!this.settings.workout.excludedExercises.includes(exercise)) {
            this.settings.workout.excludedExercises.push(exercise);
            this.saveSettings();
        }
    }

    removeExcludedExercise(exercise) {
        this.settings.workout.excludedExercises = 
            this.settings.workout.excludedExercises.filter(e => e !== exercise);
        this.saveSettings();
    }

    // Nutrition settings
    updateNutritionSettings(nutritionSettings) {
        this.settings.nutrition = {
            ...this.settings.nutrition,
            ...nutritionSettings
        };
        this.saveSettings();
    }

    addDietaryRestriction(restriction) {
        if (!this.settings.nutrition.dietaryRestrictions.includes(restriction)) {
            this.settings.nutrition.dietaryRestrictions.push(restriction);
            this.saveSettings();
        }
    }

    removeDietaryRestriction(restriction) {
        this.settings.nutrition.dietaryRestrictions = 
            this.settings.nutrition.dietaryRestrictions.filter(r => r !== restriction);
        this.saveSettings();
    }

    addMealPreference(preference) {
        if (!this.settings.nutrition.mealPreferences.includes(preference)) {
            this.settings.nutrition.mealPreferences.push(preference);
            this.saveSettings();
        }
    }

    removeMealPreference(preference) {
        this.settings.nutrition.mealPreferences = 
            this.settings.nutrition.mealPreferences.filter(p => p !== preference);
        this.saveSettings();
    }

    // Social settings
    updateSocialSettings(socialSettings) {
        this.settings.social = {
            ...this.settings.social,
            ...socialSettings
        };
        this.saveSettings();
    }

    // Settings persistence
    saveSettings() {
        try {
            localStorage.setItem('fitnessAppSettings', JSON.stringify(this.settings));
        } catch (error) {
            console.error('Error saving settings:', error);
        }
    }

    loadSettings() {
        try {
            const savedSettings = localStorage.getItem('fitnessAppSettings');
            if (savedSettings) {
                this.settings = JSON.parse(savedSettings);
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    // Settings retrieval
    getSettings() {
        return this.settings;
    }

    getProfile() {
        return this.settings.profile;
    }

    getPreferences() {
        return this.settings.preferences;
    }

    getWorkoutSettings() {
        return this.settings.workout;
    }

    getNutritionSettings() {
        return this.settings.nutrition;
    }

    getSocialSettings() {
        return this.settings.social;
    }

    // Settings validation
    validateSettings() {
        const validation = {
            isValid: true,
            errors: []
        };

        // Profile validation
        if (!this.settings.profile.name) {
            validation.isValid = false;
            validation.errors.push('Name is required');
        }

        if (!this.settings.profile.email) {
            validation.isValid = false;
            validation.errors.push('Email is required');
        }

        // Workout settings validation
        if (this.settings.workout.defaultDuration < 0) {
            validation.isValid = false;
            validation.errors.push('Default duration cannot be negative');
        }

        // Nutrition settings validation
        if (this.settings.nutrition.waterGoal < 0) {
            validation.isValid = false;
            validation.errors.push('Water goal cannot be negative');
        }

        if (this.settings.nutrition.calorieGoal < 0) {
            validation.isValid = false;
            validation.errors.push('Calorie goal cannot be negative');
        }

        const macroSum = Object.values(this.settings.nutrition.macroGoals)
            .reduce((sum, value) => sum + value, 0);
        if (macroSum !== 100) {
            validation.isValid = false;
            validation.errors.push('Macro goals must sum to 100%');
        }

        return validation;
    }

    // Settings reset
    resetSettings() {
        this.settings = {
            profile: {
                name: '',
                email: '',
                age: null,
                gender: '',
                height: null,
                weight: null,
                fitnessLevel: 'beginner',
                goals: []
            },
            preferences: {
                theme: 'light',
                language: 'en',
                units: 'metric',
                notifications: {
                    workout: true,
                    nutrition: true,
                    progress: true,
                    social: true,
                    system: true
                },
                privacy: {
                    profileVisibility: 'public',
                    showProgress: true,
                    showWorkouts: true,
                    showNutrition: true
                }
            },
            workout: {
                defaultDuration: 45,
                restBetweenSets: 60,
                warmupDuration: 10,
                cooldownDuration: 5,
                preferredExercises: [],
                excludedExercises: []
            },
            nutrition: {
                dietaryRestrictions: [],
                mealPreferences: [],
                waterGoal: 2000,
                calorieGoal: 2000,
                macroGoals: {
                    protein: 30,
                    carbs: 40,
                    fats: 30
                }
            },
            social: {
                autoShare: false,
                shareWorkouts: false,
                shareProgress: false,
                shareNutrition: false,
                allowChallenges: true,
                allowMessages: true
            }
        };
        this.saveSettings();
    }
}

export default SettingsManager; 