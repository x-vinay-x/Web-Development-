class AnalyticsManager {
    constructor() {
        this.workoutData = [];
        this.nutritionData = [];
        this.progressData = [];
        this.userMetrics = {};
    }

    // Workout analytics
    addWorkoutData(workout) {
        this.workoutData.push({
            ...workout,
            timestamp: new Date()
        });
        this.updateWorkoutAnalytics();
    }

    updateWorkoutAnalytics() {
        this.userMetrics.workoutAnalytics = {
            totalWorkouts: this.workoutData.length,
            averageDuration: this.calculateAverageWorkoutDuration(),
            mostFrequentExercises: this.getMostFrequentExercises(),
            workoutConsistency: this.calculateWorkoutConsistency(),
            progressOverTime: this.calculateWorkoutProgress()
        };
    }

    // Nutrition analytics
    addNutritionData(nutrition) {
        this.nutritionData.push({
            ...nutrition,
            timestamp: new Date()
        });
        this.updateNutritionAnalytics();
    }

    updateNutritionAnalytics() {
        this.userMetrics.nutritionAnalytics = {
            averageCalories: this.calculateAverageCalories(),
            macroDistribution: this.calculateMacroDistribution(),
            mealTiming: this.analyzeMealTiming(),
            nutritionConsistency: this.calculateNutritionConsistency()
        };
    }

    // Progress analytics
    addProgressData(progress) {
        this.progressData.push({
            ...progress,
            timestamp: new Date()
        });
        this.updateProgressAnalytics();
    }

    updateProgressAnalytics() {
        this.userMetrics.progressAnalytics = {
            weightProgress: this.calculateWeightProgress(),
            bodyMeasurements: this.calculateBodyMeasurements(),
            strengthProgress: this.calculateStrengthProgress(),
            overallProgress: this.calculateOverallProgress()
        };
    }

    // Analytics calculation methods
    calculateAverageWorkoutDuration() {
        if (this.workoutData.length === 0) return 0;
        const totalDuration = this.workoutData.reduce((sum, workout) => 
            sum + (workout.duration || 0), 0);
        return totalDuration / this.workoutData.length;
    }

    getMostFrequentExercises() {
        const exerciseCount = {};
        this.workoutData.forEach(workout => {
            workout.exercises.forEach(exercise => {
                exerciseCount[exercise.name] = (exerciseCount[exercise.name] || 0) + 1;
            });
        });
        return Object.entries(exerciseCount)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 5)
            .map(([name, count]) => ({ name, count }));
    }

    calculateWorkoutConsistency() {
        if (this.workoutData.length === 0) return 0;
        const dates = this.workoutData.map(w => 
            new Date(w.timestamp).toDateString());
        const uniqueDates = new Set(dates).size;
        const totalDays = Math.ceil(
            (new Date() - new Date(this.workoutData[0].timestamp)) / 
            (1000 * 60 * 60 * 24)
        );
        return (uniqueDates / totalDays) * 100;
    }

    calculateWorkoutProgress() {
        return this.workoutData.map(workout => ({
            date: workout.timestamp,
            duration: workout.duration,
            intensity: workout.intensity,
            exercises: workout.exercises.length
        }));
    }

    calculateAverageCalories() {
        if (this.nutritionData.length === 0) return 0;
        const totalCalories = this.nutritionData.reduce((sum, meal) => 
            sum + (meal.calories || 0), 0);
        return totalCalories / this.nutritionData.length;
    }

    calculateMacroDistribution() {
        if (this.nutritionData.length === 0) return { protein: 0, carbs: 0, fats: 0 };
        const totalMacros = this.nutritionData.reduce((sum, meal) => ({
            protein: sum.protein + (meal.protein || 0),
            carbs: sum.carbs + (meal.carbs || 0),
            fats: sum.fats + (meal.fats || 0)
        }), { protein: 0, carbs: 0, fats: 0 });

        const total = totalMacros.protein + totalMacros.carbs + totalMacros.fats;
        return {
            protein: (totalMacros.protein / total) * 100,
            carbs: (totalMacros.carbs / total) * 100,
            fats: (totalMacros.fats / total) * 100
        };
    }

    analyzeMealTiming() {
        return this.nutritionData.map(meal => ({
            time: meal.timestamp,
            type: meal.type,
            calories: meal.calories
        }));
    }

    calculateNutritionConsistency() {
        if (this.nutritionData.length === 0) return 0;
        const dates = this.nutritionData.map(n => 
            new Date(n.timestamp).toDateString());
        const uniqueDates = new Set(dates).size;
        const totalDays = Math.ceil(
            (new Date() - new Date(this.nutritionData[0].timestamp)) / 
            (1000 * 60 * 60 * 24)
        );
        return (uniqueDates / totalDays) * 100;
    }

    calculateWeightProgress() {
        return this.progressData
            .filter(p => p.weight)
            .map(p => ({
                date: p.timestamp,
                weight: p.weight
            }));
    }

    calculateBodyMeasurements() {
        return this.progressData
            .filter(p => p.measurements)
            .map(p => ({
                date: p.timestamp,
                measurements: p.measurements
            }));
    }

    calculateStrengthProgress() {
        return this.progressData
            .filter(p => p.strengthMetrics)
            .map(p => ({
                date: p.timestamp,
                metrics: p.strengthMetrics
            }));
    }

    calculateOverallProgress() {
        const weightProgress = this.calculateWeightProgress();
        const strengthProgress = this.calculateStrengthProgress();
        const workoutProgress = this.calculateWorkoutProgress();

        return {
            weightChange: this.calculateWeightChange(weightProgress),
            strengthImprovement: this.calculateStrengthImprovement(strengthProgress),
            workoutImprovement: this.calculateWorkoutImprovement(workoutProgress)
        };
    }

    calculateWeightChange(weightProgress) {
        if (weightProgress.length < 2) return 0;
        const firstWeight = weightProgress[0].weight;
        const lastWeight = weightProgress[weightProgress.length - 1].weight;
        return lastWeight - firstWeight;
    }

    calculateStrengthImprovement(strengthProgress) {
        if (strengthProgress.length < 2) return 0;
        // Implement strength improvement calculation
        return 0; // Placeholder
    }

    calculateWorkoutImprovement(workoutProgress) {
        if (workoutProgress.length < 2) return 0;
        // Implement workout improvement calculation
        return 0; // Placeholder
    }

    // Get analytics data
    getAnalytics() {
        return {
            workoutAnalytics: this.userMetrics.workoutAnalytics,
            nutritionAnalytics: this.userMetrics.nutritionAnalytics,
            progressAnalytics: this.userMetrics.progressAnalytics
        };
    }
}

export default AnalyticsManager; 