class SocialFeatures {
    constructor() {
        this.friends = [];
        this.challenges = [];
        this.posts = [];
        this.groups = [];
    }

    // Friend management
    addFriend(user) {
        this.friends.push({
            ...user,
            dateAdded: new Date()
        });
    }

    removeFriend(userId) {
        this.friends = this.friends.filter(friend => friend.id !== userId);
    }

    // Challenge management
    createChallenge(challenge) {
        this.challenges.push({
            ...challenge,
            id: Date.now(),
            createdAt: new Date(),
            participants: [],
            status: 'active'
        });
    }

    joinChallenge(challengeId, userId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge) {
            challenge.participants.push({
                userId,
                joinedAt: new Date()
            });
        }
    }

    // Post management
    createPost(post) {
        this.posts.push({
            ...post,
            id: Date.now(),
            createdAt: new Date(),
            likes: 0,
            comments: []
        });
    }

    likePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            post.likes++;
        }
    }

    addComment(postId, comment) {
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            post.comments.push({
                ...comment,
                id: Date.now(),
                createdAt: new Date()
            });
        }
    }

    // Group management
    createGroup(group) {
        this.groups.push({
            ...group,
            id: Date.now(),
            createdAt: new Date(),
            members: [],
            workouts: []
        });
    }

    joinGroup(groupId, userId) {
        const group = this.groups.find(g => g.id === groupId);
        if (group) {
            group.members.push({
                userId,
                joinedAt: new Date()
            });
        }
    }

    // Get social feed
    getSocialFeed() {
        return {
            posts: this.posts.sort((a, b) => b.createdAt - a.createdAt),
            challenges: this.challenges.filter(c => c.status === 'active'),
            groups: this.groups
        };
    }

    // Get user activity
    getUserActivity(userId) {
        return {
            posts: this.posts.filter(p => p.userId === userId),
            challenges: this.challenges.filter(c => 
                c.participants.some(p => p.userId === userId)
            ),
            groups: this.groups.filter(g => 
                g.members.some(m => m.userId === userId)
            )
        };
    }
}

export default SocialFeatures; 