class ChallengeManager {
    constructor() {
        this.challenges = [];
        this.participants = {};
        this.challengeTypes = {
            WORKOUT: 'workout',
            NUTRITION: 'nutrition',
            PROGRESS: 'progress',
            STREAK: 'streak'
        };
    }

    // Challenge creation
    createChallenge(type, name, description, requirements, duration, rewards) {
        const challenge = {
            id: this.generateId(),
            type,
            name,
            description,
            requirements,
            duration,
            rewards,
            startDate: null,
            endDate: null,
            status: 'pending',
            participants: [],
            leaderboard: []
        };

        this.challenges.push(challenge);
        return challenge;
    }

    // Workout challenges
    createWorkoutChallenge(name, description, requirements, duration, rewards) {
        return this.createChallenge(
            this.challengeTypes.WORKOUT,
            name,
            description,
            requirements,
            duration,
            rewards
        );
    }

    // Nutrition challenges
    createNutritionChallenge(name, description, requirements, duration, rewards) {
        return this.createChallenge(
            this.challengeTypes.NUTRITION,
            name,
            description,
            requirements,
            duration,
            rewards
        );
    }

    // Progress challenges
    createProgressChallenge(name, description, requirements, duration, rewards) {
        return this.createChallenge(
            this.challengeTypes.PROGRESS,
            name,
            description,
            requirements,
            duration,
            rewards
        );
    }

    // Streak challenges
    createStreakChallenge(name, description, requirements, duration, rewards) {
        return this.createChallenge(
            this.challengeTypes.STREAK,
            name,
            description,
            requirements,
            duration,
            rewards
        );
    }

    // Challenge management
    startChallenge(challengeId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge && challenge.status === 'pending') {
            challenge.startDate = new Date();
            challenge.endDate = new Date(challenge.startDate.getTime() + challenge.duration * 24 * 60 * 60 * 1000);
            challenge.status = 'active';
            this.notifyChallengeStarted(challenge);
        }
    }

    endChallenge(challengeId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge && challenge.status === 'active') {
            challenge.status = 'completed';
            this.calculateFinalResults(challenge);
            this.distributeRewards(challenge);
            this.notifyChallengeEnded(challenge);
        }
    }

    // Participant management
    joinChallenge(challengeId, userId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge && challenge.status === 'active') {
            if (!challenge.participants.includes(userId)) {
                challenge.participants.push(userId);
                this.initializeParticipantProgress(challengeId, userId);
                this.notifyParticipantJoined(challenge, userId);
            }
        }
    }

    leaveChallenge(challengeId, userId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge) {
            challenge.participants = challenge.participants.filter(id => id !== userId);
            delete this.participants[`${challengeId}-${userId}`];
            this.notifyParticipantLeft(challenge, userId);
        }
    }

    // Progress tracking
    updateProgress(challengeId, userId, progress) {
        const key = `${challengeId}-${userId}`;
        if (this.participants[key]) {
            this.participants[key].progress = {
                ...this.participants[key].progress,
                ...progress
            };
            this.updateLeaderboard(challengeId);
        }
    }

    initializeParticipantProgress(challengeId, userId) {
        const key = `${challengeId}-${userId}`;
        this.participants[key] = {
            userId,
            progress: {},
            startDate: new Date()
        };
    }

    // Leaderboard management
    updateLeaderboard(challengeId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        if (challenge) {
            challenge.leaderboard = this.calculateLeaderboard(challenge);
        }
    }

    calculateLeaderboard(challenge) {
        const participants = challenge.participants.map(userId => ({
            userId,
            ...this.participants[`${challenge.id}-${userId}`]
        }));

        return participants
            .map(participant => ({
                ...participant,
                score: this.calculateScore(challenge, participant)
            }))
            .sort((a, b) => b.score - a.score);
    }

    calculateScore(challenge, participant) {
        const progress = participant.progress;
        let score = 0;

        switch (challenge.type) {
            case this.challengeTypes.WORKOUT:
                score = this.calculateWorkoutScore(progress);
                break;
            case this.challengeTypes.NUTRITION:
                score = this.calculateNutritionScore(progress);
                break;
            case this.challengeTypes.PROGRESS:
                score = this.calculateProgressScore(progress);
                break;
            case this.challengeTypes.STREAK:
                score = this.calculateStreakScore(progress);
                break;
        }

        return score;
    }

    calculateWorkoutScore(progress) {
        // Implement workout score calculation
        return 0; // Placeholder
    }

    calculateNutritionScore(progress) {
        // Implement nutrition score calculation
        return 0; // Placeholder
    }

    calculateProgressScore(progress) {
        // Implement progress score calculation
        return 0; // Placeholder
    }

    calculateStreakScore(progress) {
        // Implement streak score calculation
        return 0; // Placeholder
    }

    // Results and rewards
    calculateFinalResults(challenge) {
        const leaderboard = this.calculateLeaderboard(challenge);
        challenge.finalResults = leaderboard;
    }

    distributeRewards(challenge) {
        if (challenge.finalResults && challenge.rewards) {
            challenge.finalResults.forEach((result, index) => {
                const reward = this.determineReward(challenge.rewards, index);
                if (reward) {
                    this.notifyRewardEarned(challenge, result.userId, reward);
                }
            });
        }
    }

    determineReward(rewards, position) {
        if (position === 0 && rewards.first) return rewards.first;
        if (position === 1 && rewards.second) return rewards.second;
        if (position === 2 && rewards.third) return rewards.third;
        return rewards.participation;
    }

    // Helper methods
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    notifyChallengeStarted(challenge) {
        // Implement notification logic
        console.log(`Challenge started: ${challenge.name}`);
    }

    notifyChallengeEnded(challenge) {
        // Implement notification logic
        console.log(`Challenge ended: ${challenge.name}`);
    }

    notifyParticipantJoined(challenge, userId) {
        // Implement notification logic
        console.log(`User ${userId} joined challenge: ${challenge.name}`);
    }

    notifyParticipantLeft(challenge, userId) {
        // Implement notification logic
        console.log(`User ${userId} left challenge: ${challenge.name}`);
    }

    notifyRewardEarned(challenge, userId, reward) {
        // Implement notification logic
        console.log(`User ${userId} earned reward in challenge: ${challenge.name}`);
    }

    // Get challenges
    getChallenges(options = {}) {
        let filtered = [...this.challenges];

        if (options.type) {
            filtered = filtered.filter(c => c.type === options.type);
        }

        if (options.status) {
            filtered = filtered.filter(c => c.status === options.status);
        }

        return filtered.sort((a, b) => {
            if (a.status === b.status) {
                return new Date(b.startDate) - new Date(a.startDate);
            }
            return a.status === 'active' ? -1 : 1;
        });
    }

    getChallengeById(challengeId) {
        return this.challenges.find(c => c.id === challengeId);
    }

    getParticipantProgress(challengeId, userId) {
        return this.participants[`${challengeId}-${userId}`];
    }

    getLeaderboard(challengeId) {
        const challenge = this.challenges.find(c => c.id === challengeId);
        return challenge ? challenge.leaderboard : [];
    }
}

export default ChallengeManager; 