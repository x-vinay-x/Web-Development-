class WorkoutManager {
    constructor() {
        this.workouts = [];
        this.exerciseLibrary = new Map();
        this.timers = new Map();
        this.difficultyLevels = ['beginner', 'intermediate', 'advanced'];
    }

    // Workout plan management
    createWorkoutPlan(plan) {
        this.workouts.push({
            ...plan,
            id: Date.now(),
            createdAt: new Date(),
            status: 'active',
            progress: 0
        });
    }

    // Exercise library management
    addExercise(exercise) {
        this.exerciseLibrary.set(exercise.id, {
            ...exercise,
            addedAt: new Date(),
            videoUrl: exercise.videoUrl,
            instructions: exercise.instructions,
            difficulty: exercise.difficulty || 'beginner'
        });
    }

    getExerciseById(id) {
        return this.exerciseLibrary.get(id);
    }

    // Timer management
    startTimer(workoutId, duration) {
        const timer = {
            startTime: Date.now(),
            duration: duration * 1000, // Convert to milliseconds
            remaining: duration * 1000,
            isRunning: true
        };
        this.timers.set(workoutId, timer);
        return timer;
    }

    pauseTimer(workoutId) {
        const timer = this.timers.get(workoutId);
        if (timer && timer.isRunning) {
            timer.isRunning = false;
            timer.remaining = timer.duration - (Date.now() - timer.startTime);
        }
    }

    resumeTimer(workoutId) {
        const timer = this.timers.get(workoutId);
        if (timer && !timer.isRunning) {
            timer.isRunning = true;
            timer.startTime = Date.now() - (timer.duration - timer.remaining);
        }
    }

    // Workout tracking
    trackWorkoutProgress(workoutId, progress) {
        const workout = this.workouts.find(w => w.id === workoutId);
        if (workout) {
            workout.progress = progress;
            if (progress >= 100) {
                workout.status = 'completed';
                workout.completedAt = new Date();
            }
        }
    }

    // Get workout recommendations
    getWorkoutRecommendations(userLevel, goals) {
        return this.workouts.filter(workout => {
            const matchesLevel = workout.difficulty === userLevel;
            const matchesGoals = workout.goals.some(goal => goals.includes(goal));
            return matchesLevel && matchesGoals;
        });
    }

    // Get exercise library by category
    getExercisesByCategory(category) {
        return Array.from(this.exerciseLibrary.values())
            .filter(exercise => exercise.category === category);
    }

    // Get exercises by difficulty
    getExercisesByDifficulty(difficulty) {
        return Array.from(this.exerciseLibrary.values())
            .filter(exercise => exercise.difficulty === difficulty);
    }

    // Get active timers
    getActiveTimers() {
        return Array.from(this.timers.entries())
            .filter(([_, timer]) => timer.isRunning)
            .map(([workoutId, timer]) => ({
                workoutId,
                remaining: timer.remaining - (Date.now() - timer.startTime)
            }));
    }
}

export default WorkoutManager; 