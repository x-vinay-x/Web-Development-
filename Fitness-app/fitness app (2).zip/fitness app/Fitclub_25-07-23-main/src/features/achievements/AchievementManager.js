class AchievementManager {
    constructor() {
        this.achievements = [];
        this.rewards = [];
        this.userProgress = {};
        this.achievementTypes = {
            WORKOUT: 'workout',
            NUTRITION: 'nutrition',
            PROGRESS: 'progress',
            SOCIAL: 'social',
            STREAK: 'streak'
        };
    }

    // Achievement management
    createAchievement(type, name, description, requirements, reward) {
        const achievement = {
            id: this.generateId(),
            type,
            name,
            description,
            requirements,
            reward,
            unlocked: false,
            progress: 0,
            unlockedAt: null
        };

        this.achievements.push(achievement);
        return achievement;
    }

    // Workout achievements
    createWorkoutAchievements() {
        return [
            this.createAchievement(
                this.achievementTypes.WORKOUT,
                'First Workout',
                'Complete your first workout',
                { workouts: 1 },
                { points: 100 }
            ),
            this.createAchievement(
                this.achievementTypes.WORKOUT,
                'Workout Warrior',
                'Complete 10 workouts',
                { workouts: 10 },
                { points: 500 }
            ),
            this.createAchievement(
                this.achievementTypes.WORKOUT,
                'Fitness Master',
                'Complete 50 workouts',
                { workouts: 50 },
                { points: 1000 }
            )
        ];
    }

    // Nutrition achievements
    createNutritionAchievements() {
        return [
            this.createAchievement(
                this.achievementTypes.NUTRITION,
                'Healthy Eater',
                'Log 5 meals',
                { meals: 5 },
                { points: 100 }
            ),
            this.createAchievement(
                this.achievementTypes.NUTRITION,
                'Nutrition Expert',
                'Log 20 meals',
                { meals: 20 },
                { points: 500 }
            ),
            this.createAchievement(
                this.achievementTypes.NUTRITION,
                'Meal Master',
                'Log 50 meals',
                { meals: 50 },
                { points: 1000 }
            )
        ];
    }

    // Progress achievements
    createProgressAchievements() {
        return [
            this.createAchievement(
                this.achievementTypes.PROGRESS,
                'First Milestone',
                'Reach your first weight goal',
                { weightGoal: 1 },
                { points: 200 }
            ),
            this.createAchievement(
                this.achievementTypes.PROGRESS,
                'Progress Pro',
                'Reach 5 weight goals',
                { weightGoals: 5 },
                { points: 1000 }
            ),
            this.createAchievement(
                this.achievementTypes.PROGRESS,
                'Transformation Master',
                'Reach 10 weight goals',
                { weightGoals: 10 },
                { points: 2000 }
            )
        ];
    }

    // Social achievements
    createSocialAchievements() {
        return [
            this.createAchievement(
                this.achievementTypes.SOCIAL,
                'Social Butterfly',
                'Connect with 5 friends',
                { friends: 5 },
                { points: 200 }
            ),
            this.createAchievement(
                this.achievementTypes.SOCIAL,
                'Community Builder',
                'Connect with 20 friends',
                { friends: 20 },
                { points: 1000 }
            ),
            this.createAchievement(
                this.achievementTypes.SOCIAL,
                'Fitness Influencer',
                'Connect with 50 friends',
                { friends: 50 },
                { points: 2000 }
            )
        ];
    }

    // Streak achievements
    createStreakAchievements() {
        return [
            this.createAchievement(
                this.achievementTypes.STREAK,
                'Getting Started',
                'Maintain a 3-day workout streak',
                { streak: 3 },
                { points: 100 }
            ),
            this.createAchievement(
                this.achievementTypes.STREAK,
                'Consistency King',
                'Maintain a 7-day workout streak',
                { streak: 7 },
                { points: 500 }
            ),
            this.createAchievement(
                this.achievementTypes.STREAK,
                'Unstoppable',
                'Maintain a 30-day workout streak',
                { streak: 30 },
                { points: 2000 }
            )
        ];
    }

    // Progress tracking
    updateProgress(type, value) {
        this.userProgress[type] = (this.userProgress[type] || 0) + value;
        this.checkAchievements();
    }

    checkAchievements() {
        this.achievements.forEach(achievement => {
            if (!achievement.unlocked) {
                const progress = this.calculateProgress(achievement);
                achievement.progress = progress;

                if (progress >= 100) {
                    this.unlockAchievement(achievement);
                }
            }
        });
    }

    calculateProgress(achievement) {
        const requirements = achievement.requirements;
        let progress = 0;

        switch (achievement.type) {
            case this.achievementTypes.WORKOUT:
                progress = (this.userProgress.workouts / requirements.workouts) * 100;
                break;
            case this.achievementTypes.NUTRITION:
                progress = (this.userProgress.meals / requirements.meals) * 100;
                break;
            case this.achievementTypes.PROGRESS:
                progress = (this.userProgress.weightGoals / requirements.weightGoals) * 100;
                break;
            case this.achievementTypes.SOCIAL:
                progress = (this.userProgress.friends / requirements.friends) * 100;
                break;
            case this.achievementTypes.STREAK:
                progress = (this.userProgress.currentStreak / requirements.streak) * 100;
                break;
        }

        return Math.min(progress, 100);
    }

    unlockAchievement(achievement) {
        achievement.unlocked = true;
        achievement.unlockedAt = new Date();
        this.addReward(achievement.reward);
        this.notifyAchievementUnlocked(achievement);
    }

    // Reward management
    addReward(reward) {
        this.rewards.push({
            ...reward,
            id: this.generateId(),
            timestamp: new Date()
        });
    }

    // Helper methods
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    notifyAchievementUnlocked(achievement) {
        // Implement notification logic
        console.log(`Achievement unlocked: ${achievement.name}`);
    }

    // Get achievements
    getAchievements(options = {}) {
        let filtered = [...this.achievements];

        if (options.type) {
            filtered = filtered.filter(a => a.type === options.type);
        }

        if (options.unlocked !== undefined) {
            filtered = filtered.filter(a => a.unlocked === options.unlocked);
        }

        return filtered.sort((a, b) => {
            if (a.unlocked === b.unlocked) {
                return b.progress - a.progress;
            }
            return a.unlocked ? 1 : -1;
        });
    }

    getRewards() {
        return this.rewards;
    }

    getProgress() {
        return this.userProgress;
    }

    // Achievement statistics
    getAchievementStats() {
        const total = this.achievements.length;
        const unlocked = this.achievements.filter(a => a.unlocked).length;
        const progress = (unlocked / total) * 100;

        return {
            total,
            unlocked,
            progress,
            byType: this.getAchievementsByType()
        };
    }

    getAchievementsByType() {
        const stats = {};
        Object.values(this.achievementTypes).forEach(type => {
            const typeAchievements = this.achievements.filter(a => a.type === type);
            stats[type] = {
                total: typeAchievements.length,
                unlocked: typeAchievements.filter(a => a.unlocked).length
            };
        });
        return stats;
    }
}

export default AchievementManager; 