class NutritionManager {
    constructor() {
        this.meals = [];
        this.recipes = new Map();
        this.waterIntake = [];
        this.macros = {
            protein: 0,
            carbs: 0,
            fats: 0,
            calories: 0
        };
    }

    // Meal planning
    addMeal(meal) {
        this.meals.push({
            ...meal,
            id: Date.now(),
            date: new Date(),
            macros: this.calculateMealMacros(meal)
        });
        this.updateDailyMacros();
    }

    // Recipe management
    addRecipe(recipe) {
        this.recipes.set(recipe.id, {
            ...recipe,
            addedAt: new Date(),
            macros: this.calculateRecipeMacros(recipe)
        });
    }

    getRecipeById(id) {
        return this.recipes.get(id);
    }

    // Water intake tracking
    addWaterIntake(amount) {
        this.waterIntake.push({
            amount,
            timestamp: new Date()
        });
    }

    getDailyWaterIntake() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        return this.waterIntake
            .filter(entry => entry.timestamp >= today)
            .reduce((total, entry) => total + entry.amount, 0);
    }

    // Macro calculations
    calculateMealMacros(meal) {
        return {
            protein: meal.items.reduce((sum, item) => sum + (item.protein || 0), 0),
            carbs: meal.items.reduce((sum, item) => sum + (item.carbs || 0), 0),
            fats: meal.items.reduce((sum, item) => sum + (item.fats || 0), 0),
            calories: meal.items.reduce((sum, item) => sum + (item.calories || 0), 0)
        };
    }

    calculateRecipeMacros(recipe) {
        return {
            protein: recipe.ingredients.reduce((sum, ing) => sum + (ing.protein || 0), 0),
            carbs: recipe.ingredients.reduce((sum, ing) => sum + (ing.carbs || 0), 0),
            fats: recipe.ingredients.reduce((sum, ing) => sum + (ing.fats || 0), 0),
            calories: recipe.ingredients.reduce((sum, ing) => sum + (ing.calories || 0), 0)
        };
    }

    updateDailyMacros() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const todayMeals = this.meals.filter(meal => meal.date >= today);
        
        this.macros = todayMeals.reduce((total, meal) => ({
            protein: total.protein + meal.macros.protein,
            carbs: total.carbs + meal.macros.carbs,
            fats: total.fats + meal.macros.fats,
            calories: total.calories + meal.macros.calories
        }), { protein: 0, carbs: 0, fats: 0, calories: 0 });
    }

    // Get nutrition recommendations
    getNutritionRecommendations(goals, restrictions) {
        return {
            dailyCalories: this.calculateDailyCalories(goals),
            macroSplit: this.calculateMacroSplit(goals),
            mealSuggestions: this.getMealSuggestions(goals, restrictions)
        };
    }

    calculateDailyCalories(goals) {
        // Basic BMR calculation (simplified)
        const bmr = 2000; // This should be calculated based on user's stats
        return goals.weightLoss ? bmr - 500 : goals.weightGain ? bmr + 500 : bmr;
    }

    calculateMacroSplit(goals) {
        if (goals.weightLoss) {
            return { protein: 40, carbs: 30, fats: 30 };
        } else if (goals.muscleGain) {
            return { protein: 30, carbs: 50, fats: 20 };
        }
        return { protein: 30, carbs: 40, fats: 30 };
    }

    getMealSuggestions(goals, restrictions) {
        return Array.from(this.recipes.values())
            .filter(recipe => {
                const matchesRestrictions = !restrictions.some(r => 
                    recipe.ingredients.some(i => i.name.toLowerCase().includes(r.toLowerCase()))
                );
                const matchesGoals = this.recipeMatchesGoals(recipe, goals);
                return matchesRestrictions && matchesGoals;
            });
    }

    recipeMatchesGoals(recipe, goals) {
        const macros = this.calculateRecipeMacros(recipe);
        if (goals.weightLoss) {
            return macros.calories < 600;
        } else if (goals.muscleGain) {
            return macros.protein > 20;
        }
        return true;
    }
}

export default NutritionManager; 