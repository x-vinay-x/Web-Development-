class ProgressTracker {
    constructor() {
        this.workoutHistory = [];
        this.measurements = {};
        this.achievements = [];
        this.personalRecords = {};
    }

    // Track workout history
    addWorkout(workout) {
        this.workoutHistory.push({
            ...workout,
            date: new Date(),
            id: Date.now()
        });
        this.checkAchievements();
        this.updatePersonalRecords(workout);
    }

    // Track body measurements
    updateMeasurements(measurements) {
        this.measurements = {
            ...this.measurements,
            ...measurements,
            date: new Date()
        };
    }

    // Add progress photo
    addProgressPhoto(photo) {
        this.measurements.photos = this.measurements.photos || [];
        this.measurements.photos.push({
            ...photo,
            date: new Date()
        });
    }

    // Check and award achievements
    checkAchievements() {
        const newAchievements = this.calculateAchievements();
        this.achievements = [...this.achievements, ...newAchievements];
        return newAchievements;
    }

    // Update personal records
    updatePersonalRecords(workout) {
        workout.exercises.forEach(exercise => {
            if (!this.personalRecords[exercise.name] || 
                exercise.weight > this.personalRecords[exercise.name].weight) {
                this.personalRecords[exercise.name] = {
                    weight: exercise.weight,
                    reps: exercise.reps,
                    date: new Date()
                };
            }
        });
    }

    // Calculate achievements based on workout history
    calculateAchievements() {
        const achievements = [];
        const workoutCount = this.workoutHistory.length;

        if (workoutCount >= 10) achievements.push('10 Workouts Completed');
        if (workoutCount >= 50) achievements.push('50 Workouts Completed');
        if (workoutCount >= 100) achievements.push('100 Workouts Completed');

        return achievements;
    }

    // Get progress statistics
    getProgressStats() {
        return {
            totalWorkouts: this.workoutHistory.length,
            achievements: this.achievements,
            personalRecords: this.personalRecords,
            measurements: this.measurements
        };
    }
}

export default ProgressTracker; 