class GoalManager {
    constructor() {
        this.goals = [];
        this.goalTypes = {
            WEIGHT: 'weight',
            WORKOUT: 'workout',
            NUTRITION: 'nutrition',
            MEASUREMENT: 'measurement',
            CUSTOM: 'custom'
        };
    }

    // Goal creation
    createGoal(type, name, description, target, deadline, milestones = []) {
        const goal = {
            id: this.generateId(),
            type,
            name,
            description,
            target,
            current: this.getInitialValue(type),
            deadline,
            milestones,
            status: 'active',
            progress: 0,
            createdAt: new Date(),
            completedAt: null
        };

        this.goals.push(goal);
        return goal;
    }

    // Weight goals
    createWeightGoal(name, targetWeight, deadline, milestones = []) {
        return this.createGoal(
            this.goalTypes.WEIGHT,
            name,
            `Reach ${targetWeight} kg`,
            targetWeight,
            deadline,
            milestones
        );
    }

    // Workout goals
    createWorkoutGoal(name, targetWorkouts, deadline, milestones = []) {
        return this.createGoal(
            this.goalTypes.WORKOUT,
            name,
            `Complete ${targetWorkouts} workouts`,
            targetWorkouts,
            deadline,
            milestones
        );
    }

    // Nutrition goals
    createNutritionGoal(name, target, deadline, milestones = []) {
        return this.createGoal(
            this.goalTypes.NUTRITION,
            name,
            `Achieve nutrition target: ${target}`,
            target,
            deadline,
            milestones
        );
    }

    // Measurement goals
    createMeasurementGoal(name, target, deadline, milestones = []) {
        return this.createGoal(
            this.goalTypes.MEASUREMENT,
            name,
            `Reach measurement target: ${target}`,
            target,
            deadline,
            milestones
        );
    }

    // Custom goals
    createCustomGoal(name, description, target, deadline, milestones = []) {
        return this.createGoal(
            this.goalTypes.CUSTOM,
            name,
            description,
            target,
            deadline,
            milestones
        );
    }

    // Goal management
    updateGoalProgress(goalId, progress) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal && goal.status === 'active') {
            goal.current = progress;
            goal.progress = this.calculateProgress(goal);
            this.checkMilestones(goal);
            this.checkGoalCompletion(goal);
        }
    }

    checkMilestones(goal) {
        goal.milestones.forEach(milestone => {
            if (!milestone.completed && goal.progress >= milestone.target) {
                milestone.completed = true;
                milestone.completedAt = new Date();
                this.notifyMilestoneReached(goal, milestone);
            }
        });
    }

    checkGoalCompletion(goal) {
        if (goal.progress >= 100) {
            goal.status = 'completed';
            goal.completedAt = new Date();
            this.notifyGoalCompleted(goal);
        }
    }

    // Progress calculation
    calculateProgress(goal) {
        let progress = 0;

        switch (goal.type) {
            case this.goalTypes.WEIGHT:
                progress = this.calculateWeightProgress(goal);
                break;
            case this.goalTypes.WORKOUT:
                progress = this.calculateWorkoutProgress(goal);
                break;
            case this.goalTypes.NUTRITION:
                progress = this.calculateNutritionProgress(goal);
                break;
            case this.goalTypes.MEASUREMENT:
                progress = this.calculateMeasurementProgress(goal);
                break;
            case this.goalTypes.CUSTOM:
                progress = this.calculateCustomProgress(goal);
                break;
        }

        return Math.min(progress, 100);
    }

    calculateWeightProgress(goal) {
        const startWeight = goal.milestones[0]?.target || goal.current;
        const weightDiff = startWeight - goal.target;
        const currentDiff = startWeight - goal.current;
        return (currentDiff / weightDiff) * 100;
    }

    calculateWorkoutProgress(goal) {
        return (goal.current / goal.target) * 100;
    }

    calculateNutritionProgress(goal) {
        // Implement nutrition progress calculation
        return 0; // Placeholder
    }

    calculateMeasurementProgress(goal) {
        // Implement measurement progress calculation
        return 0; // Placeholder
    }

    calculateCustomProgress(goal) {
        // Implement custom progress calculation
        return 0; // Placeholder
    }

    // Goal modification
    updateGoal(goalId, updates) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal) {
            Object.assign(goal, updates);
            goal.progress = this.calculateProgress(goal);
            this.checkMilestones(goal);
            this.checkGoalCompletion(goal);
        }
    }

    addMilestone(goalId, milestone) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal) {
            goal.milestones.push({
                ...milestone,
                completed: false,
                completedAt: null
            });
            goal.milestones.sort((a, b) => a.target - b.target);
        }
    }

    removeMilestone(goalId, milestoneId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal) {
            goal.milestones = goal.milestones.filter(m => m.id !== milestoneId);
        }
    }

    // Goal status
    completeGoal(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal && goal.status === 'active') {
            goal.status = 'completed';
            goal.completedAt = new Date();
            goal.progress = 100;
            this.notifyGoalCompleted(goal);
        }
    }

    archiveGoal(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal) {
            goal.status = 'archived';
        }
    }

    // Helper methods
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    getInitialValue(type) {
        switch (type) {
            case this.goalTypes.WEIGHT:
                return 0;
            case this.goalTypes.WORKOUT:
                return 0;
            case this.goalTypes.NUTRITION:
                return {};
            case this.goalTypes.MEASUREMENT:
                return {};
            case this.goalTypes.CUSTOM:
                return 0;
            default:
                return 0;
        }
    }

    notifyMilestoneReached(goal, milestone) {
        // Implement notification logic
        console.log(`Milestone reached for goal: ${goal.name}`);
    }

    notifyGoalCompleted(goal) {
        // Implement notification logic
        console.log(`Goal completed: ${goal.name}`);
    }

    // Get goals
    getGoals(options = {}) {
        let filtered = [...this.goals];

        if (options.type) {
            filtered = filtered.filter(g => g.type === options.type);
        }

        if (options.status) {
            filtered = filtered.filter(g => g.status === options.status);
        }

        return filtered.sort((a, b) => {
            if (a.status === b.status) {
                return new Date(b.createdAt) - new Date(a.createdAt);
            }
            return a.status === 'active' ? -1 : 1;
        });
    }

    getGoalById(goalId) {
        return this.goals.find(g => g.id === goalId);
    }

    getActiveGoals() {
        return this.goals.filter(g => g.status === 'active');
    }

    getCompletedGoals() {
        return this.goals.filter(g => g.status === 'completed');
    }

    getArchivedGoals() {
        return this.goals.filter(g => g.status === 'archived');
    }

    // Goal statistics
    getGoalStats() {
        const total = this.goals.length;
        const active = this.goals.filter(g => g.status === 'active').length;
        const completed = this.goals.filter(g => g.status === 'completed').length;
        const archived = this.goals.filter(g => g.status === 'archived').length;

        return {
            total,
            active,
            completed,
            archived,
            completionRate: total > 0 ? (completed / total) * 100 : 0
        };
    }
}

export default GoalManager; 