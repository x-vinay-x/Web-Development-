class NotificationManager {
    constructor() {
        this.notifications = [];
        this.subscribers = new Set();
        this.notificationTypes = {
            WORKOUT: 'workout',
            NUTRITION: 'nutrition',
            PROGRESS: 'progress',
            SOCIAL: 'social',
            SYSTEM: 'system'
        };
    }

    // Notification creation
    createNotification(type, title, message, data = {}) {
        const notification = {
            id: this.generateNotificationId(),
            type,
            title,
            message,
            data,
            timestamp: new Date(),
            read: false
        };

        this.notifications.push(notification);
        this.notifySubscribers(notification);
        return notification;
    }

    // Workout notifications
    createWorkoutReminder(workout) {
        return this.createNotification(
            this.notificationTypes.WORKOUT,
            'Workout Reminder',
            `Time for your ${workout.type} workout!`,
            { workout }
        );
    }

    createWorkoutComplete(workout) {
        return this.createNotification(
            this.notificationTypes.WORKOUT,
            'Workout Complete!',
            `Great job completing your ${workout.type} workout!`,
            { workout }
        );
    }

    // Nutrition notifications
    createMealReminder(meal) {
        return this.createNotification(
            this.notificationTypes.NUTRITION,
            'Meal Reminder',
            `Time for your ${meal.type} meal!`,
            { meal }
        );
    }

    createWaterReminder() {
        return this.createNotification(
            this.notificationTypes.NUTRITION,
            'Stay Hydrated!',
            'Remember to drink water throughout the day.',
            { type: 'water' }
        );
    }

    // Progress notifications
    createProgressUpdate(progress) {
        return this.createNotification(
            this.notificationTypes.PROGRESS,
            'Progress Update',
            'Check out your latest progress!',
            { progress }
        );
    }

    createGoalAchieved(goal) {
        return this.createNotification(
            this.notificationTypes.PROGRESS,
            'Goal Achieved!',
            `Congratulations! You've achieved your ${goal.type} goal!`,
            { goal }
        );
    }

    // Social notifications
    createSocialInteraction(interaction) {
        return this.createNotification(
            this.notificationTypes.SOCIAL,
            'Social Update',
            this.getSocialMessage(interaction),
            { interaction }
        );
    }

    createChallengeInvite(challenge) {
        return this.createNotification(
            this.notificationTypes.SOCIAL,
            'Challenge Invite',
            `${challenge.creator} invited you to join a challenge!`,
            { challenge }
        );
    }

    // System notifications
    createSystemUpdate(update) {
        return this.createNotification(
            this.notificationTypes.SYSTEM,
            'System Update',
            update.message,
            { update }
        );
    }

    // Notification management
    markAsRead(notificationId) {
        const notification = this.notifications.find(n => n.id === notificationId);
        if (notification) {
            notification.read = true;
            this.notifySubscribers(notification);
        }
    }

    markAllAsRead() {
        this.notifications.forEach(notification => {
            notification.read = true;
        });
        this.notifySubscribers({ type: 'all_read' });
    }

    deleteNotification(notificationId) {
        this.notifications = this.notifications.filter(n => n.id !== notificationId);
        this.notifySubscribers({ type: 'deleted', id: notificationId });
    }

    clearAllNotifications() {
        this.notifications = [];
        this.notifySubscribers({ type: 'cleared' });
    }

    // Subscription management
    subscribe(callback) {
        this.subscribers.add(callback);
        return () => this.subscribers.delete(callback);
    }

    notifySubscribers(notification) {
        this.subscribers.forEach(callback => callback(notification));
    }

    // Helper methods
    generateNotificationId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    getSocialMessage(interaction) {
        switch (interaction.type) {
            case 'like':
                return `${interaction.user} liked your post`;
            case 'comment':
                return `${interaction.user} commented on your post`;
            case 'follow':
                return `${interaction.user} started following you`;
            case 'challenge':
                return `${interaction.user} challenged you`;
            default:
                return 'New social interaction';
        }
    }

    // Get notifications
    getNotifications(options = {}) {
        let filtered = [...this.notifications];

        if (options.unreadOnly) {
            filtered = filtered.filter(n => !n.read);
        }

        if (options.type) {
            filtered = filtered.filter(n => n.type === options.type);
        }

        if (options.limit) {
            filtered = filtered.slice(0, options.limit);
        }

        return filtered.sort((a, b) => b.timestamp - a.timestamp);
    }

    getUnreadCount() {
        return this.notifications.filter(n => !n.read).length;
    }
}

export default NotificationManager; 