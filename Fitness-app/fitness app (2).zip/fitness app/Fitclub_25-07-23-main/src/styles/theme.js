export const theme = {
  colors: {
    primary: {
      main: '#1a1a1a',
      light: '#2d2d2d',
      dark: '#000000',
      contrast: '#ffffff'
    },
    secondary: {
      main: '#ff3333',
      light: '#ff6666',
      dark: '#cc0000',
      contrast: '#ffffff'
    },
    background: {
      default: '#000000',
      paper: '#1a1a1a',
      elevated: '#2d2d2d'
    },
    text: {
      primary: '#ffffff',
      secondary: '#b3b3b3',
      disabled: '#666666'
    },
    error: '#ff3333',
    warning: '#ffcc00',
    success: '#00cc66',
    info: '#3399ff'
  },
  shadows: {
    small: '0 2px 4px rgba(0, 0, 0, 0.3)',
    medium: '0 4px 8px rgba(0, 0, 0, 0.4)',
    large: '0 8px 16px rgba(0, 0, 0, 0.5)'
  },
  transitions: {
    default: '0.3s ease',
    fast: '0.15s ease',
    slow: '0.5s ease'
  },
  borderRadius: {
    small: '4px',
    medium: '8px',
    large: '16px',
    round: '50%'
  }
}; 